import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


public class JuXmlParser implements Runnable {
	public JuXmlParser(){
		
  	}
	  
	@Override
	public void run() {
		// TODO Auto-generated method stub
		File f = new File("sample.xml");
		
		try{
			FileReader fr = new FileReader(f);
			
			BufferedReader br = new BufferedReader(fr);
			
			String str = br.readLine();
			String totalXMLFile = "";
			
			while(str!=null)
			{
				totalXMLFile = totalXMLFile.concat(str);
				//System.out.println(str);
				str = br.readLine();
			}
			br.close();
			//System.out.println(totalXMLFile);

			try{
				System.out.println("Start XML parsing!!");
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

				DocumentBuilder db = dbf.newDocumentBuilder();

				Document doc = db.parse(new ByteArrayInputStream(totalXMLFile.getBytes()));
				
				Element root = doc.getDocumentElement();

				NodeList sub = root.getChildNodes();
			
			for (int i = 0; i < sub.getLength(); i++) {
			   Node subNode = sub.item(i);
			   if (subNode.getNodeType() == Node.ELEMENT_NODE) {
			    System.out.print(subNode.getNodeName() + ": "); // ������ ���
			    System.out.println(subNode.getFirstChild().getNodeValue());
			    //System.out.println();
			    int length = subNode.getChildNodes().getLength();
			    if(length > 1){
			     String text = "";
			     for(int ff=0; ff<length; ff++){
			      text = subNode.getChildNodes().item(ff).getTextContent();
			      if(!text.trim().equals("")){
			       System.out.println(text);
			      }
			     }
			    }
			    
			    /*NamedNodeMap nnm = subNode.getAttributes();
			    for (int j = 0; j < nnm.getLength(); j++) {
			     Node att = nnm.item(j);
			     if (subNode.getNodeType() == Node.ELEMENT_NODE) {
			      System.out.print(att.getNodeName() + ": "); // ������ ���
			      System.out.println(att.getNodeValue());
			     }
			    }*/
			    System.out.println();
			   }
			  }
			}
			catch(Exception e){
				System.out.println("Exception!!");
			}
		}
		catch(FileNotFoundException e){
			System.out.println("FileNotFoundException!!");
		}
		catch(IOException e){
			System.out.println("IOException!!");
		}
	}

}
