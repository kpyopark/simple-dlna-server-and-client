import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;

public class MulticastReceiver implements Runnable {
	  public static final int PORT = 1900;
	  public static final String ADDRESS = "239.255.255.250";
		
	  private DatagramSocket dSocket1;
	  private boolean useIPv6Address;

	  public MulticastReceiver(){

	  }
	  
	  public void run() {
		  MulticastSocket MultiSocket = null;
		  DatagramSocket serverSocket = null;
		  InetAddress serverAddr = null;
		  DatagramPacket dpacket = null;
		  
		  InetSocketAddress ssdpMultiGroup = null;
		  NetworkInterface ssdpMultiIf = null;
			
		  try {
			  useIPv6Address = false;
			  
			  InetAddress addr = InetAddress.getByName(ADDRESS);
			  String addrstr = ADDRESS;
			  if (addr instanceof Inet6Address)
			  {
					addrstr = "FF02::C";		//IPV6_LINK_LOCAL_ADDRESS;	//SSDP.getIPv6Address();
					useIPv6Address = true;
					System.out.println("C: IPv6");
			  }

			  serverAddr = InetAddress.getByName("239.255.255.250");
			  
			  System.out.println("C: MulticastSocket Create");
				  
				  MultiSocket = new MulticastSocket(null);
				  MultiSocket.setReuseAddress(true);
				  
				  InetSocketAddress bindSockAddr = new InetSocketAddress(PORT);
				  MultiSocket.bind(bindSockAddr);
					ssdpMultiGroup = new InetSocketAddress(InetAddress.getByName(ADDRESS), PORT);
					ssdpMultiIf = NetworkInterface.getByInetAddress(serverAddr);
					MultiSocket.joinGroup(ssdpMultiGroup, ssdpMultiIf);
					
					System.out.println("C: Join Group");
					
					byte ssdvRecvBuf[] = new byte[1024];
				  
				  dpacket = new DatagramPacket(ssdvRecvBuf, 1024);
			
		  } catch (Exception e) {
	           System.out.println("C: Error3");
	      } finally {
	    	   
	      }
		  
		  while(true) {
			  try {
				  //Receive
				  System.out.println("C: wait to receive~");
				  MultiSocket.receive(dpacket);
				  
				  System.out.println("C: receive!!");
				  InetAddress ia = dpacket.getAddress();
				  String str =  new String(dpacket.getData()).trim();
				  
				  System.out.println("C: "+ ia.getHostName()+" receive ==> \n"+str+"\n\n");
				  
				  //process, parsing
				  SSDPMessage ssdpMsg = new SSDPMessage();
				  byte[] DiscoveryData = dpacket.getData();
				  ssdpMsg.process(DiscoveryData);
				  
				  String SendData1 = 	"HTTP/1.1 200 OK\n"+
						  				"CACHE-CONTROL : max-age = 180\n"+
						  				"LOCATION: http://192.168.1.1:5431/dyndev/uuid:0014-bf09\n"+
						  				"ST: upnp:rootdevice\n"+
						  				"USN: uuid:0014-bf09::upnp:rootdevice\n";
				  
				  String SendData2 = 	"NOTIFY * HTTP/1.1\n"+
						  				"HOST: 239.255.255.250:1900\n"+
						  				"CACHE-CONTROL: max-age=180\n"+
						  				"Location: http://192.168.1.1:5431/dyndev/uuid:0014-bf09\n"+        //<-- ���� XML URL
						  				"NT: upnp:rootdevice\n"+
						  				"NTS: ssdp:alive\n"+
						  				"SERVER:LINUX/2.4 UPnP/1.0 BRCM400/1.0\n"+
						  				"USN: uuid:0014-bf09::upnp:rootdevice\n";

				  //sendData
				  dpacket.setData(SendData1.getBytes());
				  MultiSocket.send(dpacket);
				  System.out.println("C: Send");
			  } catch (Exception e) {
				  System.out.println("C: Error4");
		       } finally {
		    	   
		       }
			  
			  

			  //return;
		  }
	  }
}
