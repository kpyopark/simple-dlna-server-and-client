import java.lang.*;

public class First {
	public static void main(String ar[])
	{
		System.out.println("hello world");
		MulticastReceiver mr =  new MulticastReceiver();
		mr.run();
		
		JuXmlParser xp =  new JuXmlParser();
		xp.run();
	}
}
