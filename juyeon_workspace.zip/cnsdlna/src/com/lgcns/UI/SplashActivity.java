package com.lgcns.UI;

import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.os.Bundle;

public class SplashActivity extends Activity{
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle saveInstanceState) {
		super.onCreate(saveInstanceState);
		setContentView(R.layout.splash);
		
		Handler handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				finish();
			}
		};
		handler.sendEmptyMessageDelayed(0, 3000);
	}	
}
