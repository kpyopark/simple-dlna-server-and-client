package com.lgcns.UI;

import java.util.ArrayList;
import java.util.Iterator;

import com.lgcns.sol.upnp.discovery.SSDPMessage;
import com.lgcns.ssdp.ProcessSsdp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class CnsdlnaActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.main);
        
        Button discoverBtn = (Button)findViewById(R.id.button1);
        ListView myListView = (ListView)findViewById(R.id.listView1);
        final EditText myEditText = (EditText)findViewById(R.id.editText1);
        
        System.out.println("C: Start SplashActivity");
        startActivity(new Intent(this, SplashActivity.class));
        System.out.println("C: WifiManager");
	  	WifiManager wm = (WifiManager)getSystemService(Context.WIFI_SERVICE);
	  	if(wm != null){
	  		WifiManager.MulticastLock multicastLock = wm.createMulticastLock("mydebufinfo");
	  		System.out.println("C: Create MulticastLock");
	  		multicastLock.acquire();
	  	}
	  		  	
        ProcessSsdp ps1 = new ProcessSsdp();
        ps1.run();

        discoverBtn.setOnClickListener(new OnClickListener() {
        	@Override
        	public void onClick(View v) {
        		Log.i("Button1", "Click");
        		SSDPMessage ssdpMsg = new SSDPMessage();
        		byte[] DiscoveryData = ssdpMsg.ReceiveStr1.getBytes();
        		ssdpMsg.process(DiscoveryData);
        	}
        });
        
        //���� ����Ʈ���� ��� ���� �迭 ����Ʈ ����
        final ArrayList<String> serverItems = new ArrayList<String>();
        //�� �迭�� ����Ʈ ��� ���� ���� �迭 ����͸� ����
        final ArrayAdapter<String> aa;
        //�ܼ��� ��Ʈ�� ������ ����Ʈ�� android �÷��� ���� �̸� ���ǵ� simple_list_item_1�� ���
        aa = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, serverItems);
        //�� �迭 ����͸� ����Ʈ ��� ���´�.
        myListView.setAdapter(aa);
        
        myEditText.setOnKeyListener(new OnKeyListener() {
        	public boolean onKey(View v, int keyCode, KeyEvent event) {
        		if(event.getAction() == KeyEvent.ACTION_DOWN)
        		if(keyCode == KeyEvent.KEYCODE_DPAD_CENTER)
        		{
        			serverItems.add(0, myEditText.getText().toString());
        			aa.notifyDataSetChanged();
        			myEditText.setText("");
        			return true;
        		}
        		return false;
        	}
        });
        
    }
 }