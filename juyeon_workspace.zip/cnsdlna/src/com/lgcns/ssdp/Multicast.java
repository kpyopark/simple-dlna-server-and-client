package com.lgcns.ssdp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;

import com.lgcns.sol.upnp.discovery.SSDPMessage;

import android.content.Context;
import android.net.wifi.WifiManager;

public class Multicast {
	  public static final int PORT = 1900;
	  public static final String ADDRESS = "239.255.255.250";
		
	  private DatagramSocket dSocket1;
	  private boolean useIPv6Address;

	  MulticastSocket MultiSocket = null;
	  DatagramSocket serverSocket = null;
	  InetAddress serverAddr = null;
	  DatagramPacket dpacket = null;
	  
	  InetSocketAddress ssdpMultiGroup = null;
	  NetworkInterface ssdpMultiIf = null;
	  
	  public Multicast(){

	  }
	  
	  private WifiManager getSystemService(String wifiService) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean Start(){
		 
		  return true;
	  }
	  
	  public void Receive(){
		  try {
			  useIPv6Address = false;
			  
			  InetAddress addr = InetAddress.getByName(ADDRESS);
			  String addrstr;
			  if (addr instanceof Inet6Address)
			  {
					addrstr = "FF02::C";		//IPV6_LINK_LOCAL_ADDRESS;	//SSDP.getIPv6Address();
					useIPv6Address = true;
					System.out.println("C: IPv6");
			  }
			  else
				  addrstr = ADDRESS;

			  serverAddr = InetAddress.getByName("239.255.255.250");
			  
			  System.out.println("C: MulticastSocket Create");
				  
			  MultiSocket = new MulticastSocket(null);
			  MultiSocket.setReuseAddress(true);
			  
			  InetSocketAddress bindSockAddr = new InetSocketAddress(PORT);
			  MultiSocket.bind(bindSockAddr);
				ssdpMultiGroup = new InetSocketAddress(InetAddress.getByName(addrstr), PORT);
				ssdpMultiIf = NetworkInterface.getByInetAddress(serverAddr);
				
				//MultiSocket.setSoTimeout(5000);
				MultiSocket.setTimeToLive(2);
				MultiSocket.joinGroup(ssdpMultiGroup, ssdpMultiIf);
				
				System.out.println("C: Join Group");
				
				byte ssdvRecvBuf[] = new byte[1024];
			  
				dpacket = new DatagramPacket(ssdvRecvBuf, 1024);
			/*
			serverAddr = InetAddress.getByName("239.255.255.250");
			MultiSocket = new MulticastSocket(PORT);
			
			byte b = 64;
			MultiSocket.setTTL(b);
			MultiSocket.joinGroup(serverAddr);
			
			byte ssdvRecvBuf[] = new byte[1024]; 
			dpacket = new DatagramPacket(ssdvRecvBuf, 1024);
			*/
		  } catch (Exception e) {
	           System.out.println("C: Error3");
	      } finally {
	    	   
	      }
		  while(true) {
			  try {
				  System.out.println("C: wait to receive~");
				  if(true) return;
				  MultiSocket.receive(dpacket);
				  
				  SSDPMessage ssdpMsg = new SSDPMessage();
				  byte[] DiscoveryData = dpacket.getData();
				  ssdpMsg.process(DiscoveryData);
				  /*
				  String SendData1 = "HTTP/1.1 200 OK\r\n"
							"CACHE-CONTROL: max-age=%u\r\n"
							"DATE: %s\r\n"
							"ST: %s%s\r\n"
							"USN: %s%s%s%s\r\n"
							"EXT:\r\n"
							"SERVER: " MINIDLNA_SERVER_STRING "\r\n"
							"LOCATION: http://%s:%u" ROOTDESC_PATH "\r\n"
							"Content-Length: 0\r\n"
							"\r\n",
							(runtime_vars.notify_interval<<1)+10,
							szTime,
							known_service_types[st_no], (st_no>1?"1":""),
							uuidvalue, (st_no>0?"::":""), (st_no>0?known_service_types[st_no]:""), (st_no>1?"1":""),
							host, (unsigned int)port);
				  
							NOTIFY *HTTP/1.1
							HOST: 239.255.255.250: 1900
							CACHE-CONTROL: max-age = seconds until advertisement expires
							LOCATION: URL for UPnP description for root device
							NT:search target
							NTS:ssdp:alive
							USN:advertisement UUID

							HTTP/1.1 200 OK
							CACHE-CONTROL : max-age = seconds until advertisement expires
							LOCATION: URL for UPnP description for root device
							ST: search target
							USN: advertisement UUID


				  dpacket.setData(SendData1.getBytes());
				  MultiSocket.send(dpacket);
				  */
			  } catch (Exception e) {
				  System.out.println("C: Error4 "+e.toString());
				  return;
		       } finally {
		    	   
		       }
			  
			  System.out.println("C: receive!!");
			  InetAddress ia = dpacket.getAddress();
			  String str =  new String(dpacket.getData()).trim();
			  
			  System.out.println("C: "+ ia.getHostName()+" receive ==> \n"+str+"\n\n");

			  //return;
		  }
	  }
}
